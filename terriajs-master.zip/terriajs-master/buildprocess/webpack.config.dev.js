module.exports = require('./webpack.config.make')(false, true);
