module.exports = require('./webpack.config.make')(true, true);
