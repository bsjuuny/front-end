Coming soon!

In the meantime, see [https://github.com/TerriaJS/terriajs-server](https://github.com/TerriaJS/terriajs-server).